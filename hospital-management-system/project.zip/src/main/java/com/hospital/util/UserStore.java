package com.hospital.util;

import com.hospital.dao.UserDAO;
import com.hospital.impl.UserDAOImpl;
import com.hospital.model.User;
import java.util.List;

public final class UserStore {
    private static final UserDAO userDAO = new UserDAOImpl();

    private UserStore() {
    }

    public static void addUser(User user) {
        userDAO.addUser(user);
    }

    public static User getUser(String username) {
        return userDAO.getUserByUsername(username);
    }

    /** Returns all users in the store. For admin/demo use only. */
    public static List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }
}
